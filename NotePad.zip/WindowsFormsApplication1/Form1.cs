﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // v0.5 Beta
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void 名前を付けて保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "テキストファイル(*.txt)|*.txt|C#ソースファイル(*.cs)|*.cs|VBsprictファイル(*.vbs)|*.vbs|Windowsコマンドスプリクト(*.cmd)|*.cmd|Windowsバッチファイル(*.bat)|*.bat|すべてのファイル(*.*)|*.*";
            //dialog.Title = "ファイルを保存する";
            if (dialog.ShowDialog() == DialogResult.OK)
                File.WriteAllText(dialog.FileName, richTextBox1.Text);
        }

        private void 開くToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "テキストファイル(*.txt)|*.txt|C#ソースファイル(*.cs)|*.cs|VBsprictファイル(*.vbs)|*.vbs|Windowsコマンドスプリクト(*.cmd)|*.cmd|Windowsバッチファイル(*.bat)|*.bat|すべてのファイル(*.*)|*.*";
            //dialog.Title = "ファイルを読み込む";
            if (dialog.ShowDialog() == DialogResult.OK)
                richTextBox1.Text = File.ReadAllText(dialog.FileName);
        }

        private void 元に戻すToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void メモ帳の終了ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void バージョン情報ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void フォントToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;

            fontDialog1.Font = richTextBox1.Font;
            fontDialog1.Color = richTextBox1.ForeColor;

            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                richTextBox1.Font = fontDialog1.Font;
                richTextBox1.ForeColor = fontDialog1.Color;


            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private static void Form1_FormClosing1(object sender, FormClosingEventArgs e)
        {
            if (DialogResult.No == MessageBox.Show(
                            "終了しますか？", "終了確認", MessageBoxButtons.YesNo))
            {
                e.Cancel = true;
            }
        }




        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void 新しいウィンドウToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var proc = new System.Diagnostics.Process();

            proc.StartInfo.FileName = @"C:\Program Files\NotePad\NotePad.exe";
            proc.Start();

            proc.WaitForExit();
        }

        private void メモ帳の終了XToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void メモ帳を閉じるXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void ページ設定UToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //PrintDocumentオブジェクトの作成
            System.Drawing.Printing.PrintDocument pd =
                new System.Drawing.Printing.PrintDocument();
            //PrintPageイベントハンドラの追加
           

            //PageSetupDialogクラスの作成
            PageSetupDialog psd = new PageSetupDialog();
            //PrintDocumentを指定
            psd.Document = pd;
            //ページ設定ダイアログを表示する
            if (psd.ShowDialog() == DialogResult.OK)
            {
                //OKがクリックされた時は印刷する
                pd.Print();
            }
        }

        private void pd_PrintPage(object sender,
            System.Drawing.Printing.PrintPageEventArgs e)
        {
            //画像を読み込む
            Image img = Image.FromFile("test.bmp");
            //画像を描画する
            e.Graphics.DrawImage(img, e.MarginBounds);
            //次のページがないことを通知する
            e.HasMorePages = false;
            //後始末をする
            img.Dispose();
        }

        private void 印刷PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //PrintDocumentオブジェクトの作成
            System.Drawing.Printing.PrintDocument pd =
                new System.Drawing.Printing.PrintDocument();
            //PrintPageイベントハンドラの追加
            

            //PrintDialogクラスの作成
            PrintDialog pdlg = new PrintDialog();
            //PrintDocumentを指定
            pdlg.Document = pd;
            //印刷の選択ダイアログを表示する
            if (pdlg.ShowDialog() == DialogResult.OK)
            {
                //OKがクリックされた時は印刷する
                pd.Print();
            }
        }

        private void 編集ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ヘルプHToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void ベータ版情報ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
    }

